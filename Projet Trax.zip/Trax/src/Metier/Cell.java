package Metier;



public class Cell {

	int haut;
	int bas;
	int gauche;
	int droite;
	//Une tuile est repr�sent�e par 4 entiers pouvant prendre les valeurs {0, 1, 5}. 
	// Chacun des entiers repr�sente un point cardinal de la tuile.
	//La valeur de l'entier correspond � une couleur selon le code suivant :
	// 0 : "pas de couleur" ; 5: "rouge", 1 : "blanc"

	public int getHaut() {
		return haut;	
	}
	public int getBas() {
		return bas;
	}
	public int getGauche() {
		return gauche;
	}
	public int getDroite() {
		return droite;
	}
	
	public void setGauche(int gauche) {
		this.gauche = gauche;
	}
	public void setDroite(int droite) {
		this.droite = droite;
	}
	public void setHaut(int haut) {
		this.haut = haut;
	}
	public void setBas(int bas) {
		this.bas = bas;
	}

	public Cell (int haut, int bas, int gauche, int droite) {
		this.haut=haut;
		this.bas=bas;
		this.gauche=gauche;
		this.droite=droite;
	}
	
	
	public String toString () {
		String l = "haut : "+ this.haut + " bas : " +this.bas + " gauche : " +this.gauche + " droite : " +this.droite;
		return(l);
	}


}