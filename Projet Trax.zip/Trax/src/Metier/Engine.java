package Metier;

import java.util.ArrayList;
import IHM.GameWindow;


public class Engine {
	
	int H;  //Hauteur du plateau
	int L;  //Longeur du plateau
	Cell[][] plateau;
	int gagnant;
	
	public int getgagnant() {
		return this.gagnant;
	}
	
	public Cell[][] getPlateau() {
		return plateau;
	}
	
	public int getH() {
		return this.H;
	}
	public int getL() {
		return this.L;
	}
	public void setH(int h) {
		H = h;
	}
	public void setL(int l) {
		L = l;
	}
	
	public Engine (){
		this.setH(8);
		this.setL(8);
		Cell[][] tab = new Cell[H][L];
		for (int i = 0; i < H; i++) {
			for (int j = 0; j < L; j++) {
				Cell val= new Cell(0, 0, 0, 0);
				tab[i][j]=val;
			}
		}
		this.plateau=tab;
		tab[3][3].setBas(1);
		tab[3][3].setHaut(1);
		tab[3][3].setGauche(5);
		tab[3][3].setDroite(5);
	}
	
	public boolean isEmpty(int i, int j) { //Renvoie true si la case est vide
		if (this.plateau[i][j].getBas()+this.plateau[i][j].getHaut()+this.plateau[i][j].getGauche()+this.plateau[i][j].getDroite() ==0 ) {
			return true;
		}
		return false;
	}
	
	public boolean tuileExiste (int haut, int bas, int gauche, int droite) {
	if (haut+bas+gauche+droite!=12){     // On joue avec 0 pour rien, 1 pour blanc et 5 pour noir
		return false;
		}
	return true;
	}
	
	public boolean caseAuCentre(int i, int j) { // Renvoie true si la case n'est pas sur un bord du plateau
		if(i!=0 && i!= (this.H -1) && j!=0 && j!= (this.L -1)){
			return true;		
		}
		return false;
	}
	
	public boolean caseEnHautPasCoin(int i, int j) { // Renvoie true si la case est en haut mais pas dans un coin
		if (i==0 && j!=0 && j!= (this.L -1)) { 
			return true;
		}
		return false;
	}
	
	public boolean caseEnBasPasCoin(int i, int j) { // Renvoie true si la case est en bas mais pas dans un coin
		if (i==(this.H -1) && j!=0 && j!= (this.L -1)) {
			return true;
		}
		return false;
	}
	
	public boolean caseAGauchePasCoin(int i, int j) { // Renvoie true si la case est � gauche mais pas dans un coin
		if (i!=0 && i!= (this.H -1) && j==0 ) {
			return true;
		}
		return false;
	}
	
	public boolean caseADroitePasCoin(int i, int j) {
		if (i!=0 && i!= (this.H -1) && j== (this.L -1)) { // Renvoie true si la case est � droite mais pas dans un coin
			return true;
		}
		return false;
	}
	
	public boolean caseCoinHautGauche(int i,int j) { // Renvoie true si la case est dans le coin en haut � gauche
		if (i==0 && j==0) {
			return true;
		}
		return false;
	}
	
	public boolean caseCoinBasGauche(int i,int j) { // Renvoie true si la case est dans le coin en bas � gauche
		if (i==(this.H -1) && j==0 ) {
			return true;
		}
		return false;
	}
	
	public boolean caseCoinHautDroite(int i, int j) { // Renvoie true si la case est dans le coin en haut � droite
		if (i==0 && j== (this.L -1)) {
			return true;
		}
		return false;
	}
	
	public boolean caseCoinBasDroite(int i, int j) { // Renvoie true si la case est dans le coin en bas � droite
		if (i==(this.H -1) && j== (this.L -1)) {
			return true;
		}
		return false;
	}
	public boolean casesCompatible(int i, int j, String direction, int haut, int bas, int gauche, int droite) { // Renvoie true si dans la tuile en (i,j) est compatible avec la tuile dans la direction donn�e
	
		if (direction=="haut") {
			if((haut==5 && this.plateau[i-1][j].getBas()==1) || (haut==1 && this.plateau[i-1][j].getBas()==5)) {
				return false;
			}
			return true;
		}
		else if (direction=="bas") {
			if((bas==5 && this.plateau[i+1][j].getHaut()==1) || (bas==1 && this.plateau[i+1][j].getHaut()==5)) {
				return false;
			}
			return true;
		}
		else if (direction=="gauche") {
			if((gauche==5 && this.plateau[i][j-1].getDroite()==1) || (gauche==1 && this.plateau[i][j-1].getDroite()==5)) {
				return false;
			}
			return true;
		}
		else {
			if((droite==5 && this.plateau[i][j+1].getGauche()==1) || (droite==1 && this.plateau[i][j+1].getGauche()==5)) {
				return false;
			}
			return true;
		}
	}
	
	
	public boolean coupPossible(int i, int j, int haut, int bas, int gauche, int droite) { //Renvoie True is on peut jouer la Tuile choisie sur la case indiqu�e
		
		if (!isEmpty(i,j)) {
			return false;
		}
		
		if (!tuileExiste(haut,bas,gauche,droite)){     
			return false;
		}
		
		if (caseAuCentre(i,j)) {     
			if (!casesCompatible(i,j,"haut", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"bas", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"gauche", haut,bas,gauche,droite)){
				return false;
			}
			if(!casesCompatible(i,j,"droite", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche()==0) {
				return false;
			}
			return true;
		}
		
		if (caseEnHautPasCoin(i,j)) {   
			if (!casesCompatible(i,j,"bas", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"gauche", haut,bas,gauche,droite)){
				return false;
			}
			if(!casesCompatible(i,j,"droite", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche()==0) {
				return false;
			}
			return true;
		}
		
		if (caseEnBasPasCoin(i,j)) {     
			if (!casesCompatible(i,j,"haut", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"gauche", haut,bas,gauche,droite)){
				return false;
			}
			if(!casesCompatible(i,j,"droite", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i-1][j].getBas()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche()==0) {
				return false;
			}
			return true;
		}
		
		if (caseAGauchePasCoin(i,j)) {     
			if (!casesCompatible(i,j,"haut", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"bas", haut,bas,gauche,droite)){
				return false;
			}
			if(!casesCompatible(i,j,"droite", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j+1].getGauche()==0) {
				return false;
			}
			return true;
		}
		
		if (caseADroitePasCoin(i,j)) {     
			if (!casesCompatible(i,j,"haut", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"bas", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"gauche", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite()==0) {
				return false;
			}
			return true;
		}
		
		if (caseCoinHautGauche(i,j)) {   
			if (!casesCompatible(i,j,"bas", haut,bas,gauche,droite)){
				return false;
			}
			if(!casesCompatible(i,j,"droite", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i+1][j].getHaut()+this.plateau[i][j+1].getGauche()==0) {
				return false;
			}
			return true;
		}
		
		if (caseCoinBasGauche(i,j)) {    
			if (!casesCompatible(i,j,"haut", haut,bas,gauche,droite)){
				return false;
			}
			if(!casesCompatible(i,j,"droite", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i-1][j].getBas()+this.plateau[i][j+1].getGauche()==0) {
				return false;
			}			
			return true;
		}
		
		if (caseCoinHautDroite(i,j)) {
			if (!casesCompatible(i,j,"bas", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"gauche", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite()==0) {
				return false;
			}
			return true;
		}
		
		if (caseCoinBasDroite(i,j)) {
			if (!casesCompatible(i,j,"haut", haut,bas,gauche,droite)){
				return false;
			}
			if (!casesCompatible(i,j,"gauche", haut,bas,gauche,droite)){
				return false;
			}
			if (this.plateau[i-1][j].getBas()+this.plateau[i][j-1].getDroite()==0) {
				return false;
			}
			return true;
		
		}
		
		return true;
		}
	
	public void addNewCell(int i, int j, int haut, int bas, int gauche, int droite) { //rajoute une Tuile sur la case indiqu�e
		this.plateau[i][j].setHaut(haut);
		this.plateau[i][j].setBas(bas);
		this.plateau[i][j].setGauche(gauche);
		this.plateau[i][j].setDroite(droite);
	}
	
	public boolean coupObligatoire(int i, int j) { //renvoie true si il faut jouer un coup obligatoire en (i,j)
		if (isEmpty(i,j)) {
			if (caseAuCentre(i,j)){
				int a = this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			if (caseEnHautPasCoin(i,j)) {
				int a = this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			if (caseEnBasPasCoin(i,j)) { 
				int a = this.plateau[i-1][j].getBas()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			if (caseAGauchePasCoin(i,j)){    
				int a = this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j+1].getGauche();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			if (caseADroitePasCoin(i,j)){
				int a = this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			if (caseCoinHautDroite(i,j)){
				int a = this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			if (caseCoinBasGauche(i,j)){ 
				int a = this.plateau[i-1][j].getBas()+this.plateau[i][j+1].getGauche();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			if (caseCoinBasDroite(i,j)){    
				int a = this.plateau[i-1][j].getBas()+this.plateau[i][j-1].getDroite();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			if (caseCoinHautGauche(i,j)){
				int a = this.plateau[i+1][j].getHaut()+this.plateau[i][j+1].getGauche();
				if (a==2  || a==7 || a==10 || a==11 || a==12) {
					return true;
				}	
			}
			
			
		}
		return false;
	}				
				
	public void jouerUnCoupObligatoire(int i,int j) { //joue un coup obligatoire en (i,j) (cette fonction ne verifie pas que le coup est effectivement obligatoire)
		if (caseAuCentre(i,j)){
			addNewCell(i, j, this.plateau[i-1][j].getBas(), this.plateau[i+1][j].getHaut(), this.plateau[i][j-1].getDroite(), this.plateau[i][j+1].getGauche());
		}
		else if (caseEnHautPasCoin(i,j)){   
			addNewCell(i, j, 0, this.plateau[i+1][j].getHaut(), this.plateau[i][j-1].getDroite(), this.plateau[i][j+1].getGauche());
		}
		else if (caseEnBasPasCoin(i,j)){
			addNewCell(i, j, this.plateau[i-1][j].getBas(), 0, this.plateau[i][j-1].getDroite(), this.plateau[i][j+1].getGauche());
		}
		else if (caseAGauchePasCoin(i,j)){  
			addNewCell(i, j, this.plateau[i-1][j].getBas(), this.plateau[i+1][j].getHaut(), 0, this.plateau[i][j+1].getGauche());
		}
		else if (caseADroitePasCoin(i,j)){     
			addNewCell(i, j, this.plateau[i-1][j].getBas(), this.plateau[i+1][j].getHaut(), this.plateau[i][j-1].getDroite(), 0);
		}
		else if (caseCoinHautDroite(i,j)){ 
			addNewCell(i, j, 0, this.plateau[i+1][j].getHaut(), this.plateau[i][j-1].getDroite(), 0);
		}
		else if (caseCoinBasGauche(i,j)){
			addNewCell(i, j, this.plateau[i-1][j].getBas(), 0, 0, this.plateau[i][j+1].getGauche());
		}
		else if (caseCoinBasDroite(i,j)){    
			addNewCell(i, j, this.plateau[i-1][j].getBas(), 0, this.plateau[i][j-1].getDroite(), 0);
		}
		else if (caseCoinHautGauche(i,j)){ 
			addNewCell(i, j, 0, this.plateau[i+1][j].getHaut(), 0, this.plateau[i][j+1].getGauche());
		}
		// cette partie du code permet de choisir la tuile a jou� en fonction des tuiles voisines (Nord,Sud,Est,Ouest)
		
		int a = this.plateau[i][j].getBas()+this.plateau[i][j].getHaut()+this.plateau[i][j].getDroite()+this.plateau[i][j].getGauche();
		if (a==11 || a==10) {
			if (this.plateau[i][j].getBas()==0) {
				this.plateau[i][j].setBas(1);
			}
			if (this.plateau[i][j].getHaut()==0) {
				this.plateau[i][j].setHaut(1);
			}
			if (this.plateau[i][j].getDroite()==0) {
				this.plateau[i][j].setDroite(1);
			}
			if (this.plateau[i][j].getGauche()==0) {
				this.plateau[i][j].setGauche(1);
			}
		}
		
		else if (a==2 || a==7) {
			if (this.plateau[i][j].getBas()==0) {
				this.plateau[i][j].setBas(5);
			}
			if (this.plateau[i][j].getHaut()==0) {
				this.plateau[i][j].setHaut(5);
			}
			if (this.plateau[i][j].getDroite()==0) {
				this.plateau[i][j].setDroite(5);
			}
			if (this.plateau[i][j].getGauche()==0) {
				this.plateau[i][j].setGauche(5);
			}
		}
		// cette partie du code g�re le cas o� une (ou plusieurs) des cases voisines ne contient pas de tuile
	}	
	
	

	
	
	public boolean situationInterdite() { // renvoie true si on aboutit � une situation interdite
		int a=0;
		for(int i=0; i<this.H; i++) {
			for(int j=0; j<this.L; j++) {
				if (isEmpty(i,j)) {
					if(caseAuCentre(i,j)){ 
						a = this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche();	
					}					
					else if (caseEnHautPasCoin(i,j)){   
						a = this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche();	
					}				
					else if (caseEnBasPasCoin(i,j)){
						a = this.plateau[i-1][j].getBas()+this.plateau[i][j-1].getDroite()+this.plateau[i][j+1].getGauche();
					}					
					else if (caseAGauchePasCoin(i,j)){
						a = this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j+1].getGauche();
					}					
					else if (caseADroitePasCoin(i,j)){ 
						a = this.plateau[i-1][j].getBas()+this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite();
					}						
					else if (caseCoinHautDroite(i,j)){   
						a = this.plateau[i+1][j].getHaut()+this.plateau[i][j-1].getDroite();
					}					
					else if (caseCoinBasGauche(i,j)){    
						a = this.plateau[i-1][j].getBas()+this.plateau[i][j+1].getGauche();
					}	
					else if (caseCoinBasDroite(i,j)){     
						a = this.plateau[i-1][j].getBas()+this.plateau[i][j-1].getDroite();
					}
					else if (caseCoinHautGauche(i,j)){ 
						a = this.plateau[i+1][j].getHaut()+this.plateau[i][j+1].getGauche();
					}
					if (a==3  || a==8 || a==15 || a==16 ) {
						return true;
					}
				}
			}
		}
	return false;
	}	
	
	public boolean jouerPlusieursCoupsObligatoires() { //joue l'ensemble des coups obligatoires qui surviennent
		ArrayList<Integer> Listi= new ArrayList<Integer>(); //on stocke l'abcisse des coups obligatoires jou�s
		ArrayList<Integer> Listj= new ArrayList<Integer>(); //on stocke l'ordonn�e des coups obligatoires jou�s
		
		int m=1; //m permet de savoir si a chaque iteration du while un coup obligatoire a �t� jou�
		while (m>0) {
			m=0;
			for(int i=0; i<this.H; i++) {
				for(int j=0; j<this.L; j++) {
					if (coupObligatoire(i,j)) {
						jouerUnCoupObligatoire(i,j);
						m+=1; //un coup obligatoire a �t� jou�
						Listi.add(i); //on note son abcisse
						Listj.add(j); // on note son ordonn�e
						
					}
				}
			}
		}
		
		if (situationInterdite()) {
			int l=Listi.size();
			for (int k=0; k<l; k++) {
			addNewCell(Listi.get(k), Listj.get(k), 0, 0, 0, 0); //on d�fait tous les coups obligatoires jou�s si on aboutit � une situation interdite	
			}
			return true;
		}
		return false;
	}
	
	public void tourDeJeu(int i, int j, int haut, int bas, int gauche, int droite) { //on pose une tuile, effectue un tour de jeu complet
		if (coupPossible(i, j, haut, bas, gauche, droite)) {
			addNewCell(i, j, haut, bas, gauche, droite);
			if (situationInterdite()) {
				addNewCell(i, j, 0, 0, 0, 0);
				System.out.println("Coup ammenant � une situation interdite, jouez un autre coup");
				return;
			}
			
			boolean interdit = jouerPlusieursCoupsObligatoires();
			if (interdit) {
				addNewCell(i, j, 0, 0, 0, 0);
				System.out.println("Coup ammenant � une situation interdite, jouez un autre coup");
				return;
			}
		}
		else {
			System.out.println("Coup ill�gal, jouez un autre coup"); 
			return;
		}		
	}
	
	public ArrayList<String> next(int i,int j, String direction) { //renvoie une liste de string contenant : les coordonn�es (i,j) de la case suivante ainsi que la direction � suivre
		ArrayList<String> resultat = new ArrayList<String>();
		
		if (direction == "gauche") {
			
			if(j==0 || isEmpty(i,j-1)) {
				resultat.add(Integer.toString(i));
				resultat.add(Integer.toString(j));
				resultat.add("none");
				return resultat;
			}
			resultat.add(Integer.toString(i));
			resultat.add(Integer.toString(j-1));			
			int a=this.plateau[i][j-1].getDroite();
			
		    if (this.plateau[i][j-1].getHaut()==a) {
				resultat.add("haut");
				return resultat;				
			}
			if (this.plateau[i][j-1].getBas()==a) {
				resultat.add("bas");
				return resultat;
			}
			if (this.plateau[i][j-1].getGauche()==a) {
				resultat.add("gauche");
				return resultat;
			}							
		}
		
		else if (direction == "droite") {
			if(j==(this.L -1) || isEmpty(i,j+1)) {
				resultat.add(Integer.toString(i));
				resultat.add(Integer.toString(j));
				resultat.add("none");
				return resultat;
			}
			
			int a=this.plateau[i][j+1].getGauche();
			resultat.add(Integer.toString(i));
			resultat.add(Integer.toString(j+1));
			
			if (this.plateau[i][j+1].getHaut()==a) {
				resultat.add("haut");
				return resultat;
			}
			if (this.plateau[i][j+1].getBas()==a) {
				resultat.add("bas");
				return resultat;
			}
			if (this.plateau[i][j+1].getDroite()==a) {
				resultat.add("droite");
				return resultat;
			}							
		}
		else if (direction == "haut") {
			if(i==0 || isEmpty(i-1,j)) {
				resultat.add(Integer.toString(i));
				resultat.add(Integer.toString(j));
				resultat.add("none");
				return resultat;
			}
			
			int a=this.plateau[i-1][j].getBas();
			resultat.add(Integer.toString(i-1));
			resultat.add(Integer.toString(j));
			
			if (this.plateau[i-1][j].getHaut()==a) {
				resultat.add("haut");
				return resultat;
			}
			if (this.plateau[i-1][j].getDroite()==a) {
				resultat.add("droite");
				return resultat;
			}
			if (this.plateau[i-1][j].getGauche()==a) {
				resultat.add("gauche");
				return resultat;
			}							
		}
		else if (direction == "bas") {
			if(i==(this.H -1) || isEmpty(i+1,j)) {
				resultat.add(Integer.toString(i));
				resultat.add(Integer.toString(j));
				resultat.add("none");
				return resultat;
			}
			
			int a=this.plateau[i+1][j].getHaut();
			resultat.add(Integer.toString(i+1));
			resultat.add(Integer.toString(j));
			
			if (this.plateau[i+1][j].getBas()==a) {
				resultat.add("bas");
				return resultat;
			}
			if (this.plateau[i+1][j].getDroite()==a) {
				resultat.add("droite");
				return resultat;
			}
			if (this.plateau[i+1][j].getGauche()==a) {
				resultat.add("gauche");
				return resultat;
			}							
		}
		return resultat;
	}
	
	public boolean boucleGagnante(int i, int j, String direction) {
		int Xcourant;
		int Ycourant;
		ArrayList<String> prochaincoup = new ArrayList<String>();
		
		prochaincoup= next(i,j,direction);
		while (prochaincoup.get(2)!="none") {
			Xcourant=Integer.parseInt(prochaincoup.get(0));
			Ycourant=Integer.parseInt(prochaincoup.get(1));
			if( Xcourant==i && Ycourant==j) {
				return true;
			}
			prochaincoup= next(Xcourant,Ycourant,prochaincoup.get(2));
		}
		return false;		
	}
	
	public boolean ligneHorizontaleGagnante(int i, int j, String direction) {
		int Xcourant;
		int Ycourant;
		ArrayList<String> prochaincoup = new ArrayList<String>();
		
		prochaincoup= next(i,j,direction);
		while (prochaincoup.get(2)!="none") {
			Xcourant=Integer.parseInt(prochaincoup.get(0));
			Ycourant=Integer.parseInt(prochaincoup.get(1));
			if( Ycourant==this.H-1) {
				return true;
			}
			prochaincoup= next(Xcourant,Ycourant,prochaincoup.get(2));
		}
		return false;
	}
	
	public boolean ligneVerticaleGagnante(int i, int j, String direction) {
		int Xcourant;
		int Ycourant;
		ArrayList<String> prochaincoup = new ArrayList<String>();
		
		prochaincoup= next(i,j,direction);
		while (prochaincoup.get(2)!="none") {
			Xcourant=Integer.parseInt(prochaincoup.get(0));
			Ycourant=Integer.parseInt(prochaincoup.get(1));
			if( Xcourant==this.L-1) {
				return true;
			}
			prochaincoup= next(Xcourant,Ycourant,prochaincoup.get(2));
		}
		return false;
	}
	
	public boolean plusDeCoups() { // � mettre dans isOver, mais comment pr�ciser le gagnant ? isOver 1 et 2 ?
		ArrayList<Integer[]> resultat = coupsPossibles();
		if(resultat.size()==0) {
			return true;
		}
		return false;
	}
	
	public boolean isOver() {
		for(int i=0; i<this.H; i++) {
			for(int j=0; j<this.L; j++) {
				if (boucleGagnante(i,j,"droite")){
					this.gagnant= this.plateau[i][j].getDroite();
					return true;
				}
				if (boucleGagnante(i,j,"gauche")){
					this.gagnant= this.plateau[i][j].getGauche();
					return true;
				}
				if (boucleGagnante(i,j,"bas")){
					this.gagnant= this.plateau[i][j].getBas();
					return true;
				}
				if (boucleGagnante(i,j,"haut")){
					this.gagnant= this.plateau[i][j].getHaut();
					return true;
				}
			}
		}
		
		for(int i=0; i<this.H; i++) {
			if (ligneHorizontaleGagnante(i,0,"droite")){
				this.gagnant= this.plateau[i][0].getDroite();
				return true;
			}
			if (ligneHorizontaleGagnante(i,0,"gauche")){
				this.gagnant= this.plateau[i][0].getGauche();
				return true;
			}
			if (ligneHorizontaleGagnante(i,0,"bas")){
				this.gagnant= this.plateau[i][0].getBas();
				return true;
			}
			if (ligneHorizontaleGagnante(i,0,"haut")){
				this.gagnant= this.plateau[i][0].getHaut();
				return true;
			}
		}
		
		for(int j=0; j<this.L; j++) {
			if (ligneVerticaleGagnante(0,j,"droite")){
				this.gagnant= this.plateau[0][j].getDroite();
				return true;
			}
			if (ligneVerticaleGagnante(0,j,"gauche")){
				this.gagnant= this.plateau[0][j].getGauche();
				return true;
			}
			if (ligneVerticaleGagnante(0,j,"bas")){
				this.gagnant= this.plateau[0][j].getBas();
				return true;
			}
			if (ligneVerticaleGagnante(0,j,"haut")){
				this.gagnant= this.plateau[0][j].getHaut();
				return true;
			}
		}
		return false;
	}
	
	public void play() {
		GameWindow fenetre =new GameWindow(this);
		fenetre.init();
	}

	public ArrayList<Integer[]> coupsPossibles() {
		ArrayList<Integer[]> resultat = new ArrayList<Integer[]>();
		for(int i=0; i<this.H; i++) {
			for(int j=0; j<this.L; j++) {
				if (coupPossible(i, j, 1, 1, 5, 5)) {
					Integer[] L= {i,j,1,1,5,5};
					resultat.add(L);
				}
				if (coupPossible(i, j, 5, 5, 1, 1)) {
					Integer[] L= {i,j,5,5,1,1};
					resultat.add(L);
				}
				if (coupPossible(i, j, 1, 5, 5, 1)) {
					Integer[] L= {i,j,1,5,5,1};
					resultat.add(L);
				}
				if (coupPossible(i, j, 5, 1, 5, 1)) {
					Integer[] L= {i,j,5,1,5,1};
					resultat.add(L);
				}
				if (coupPossible(i, j, 5, 1, 1, 5)) {
					Integer[] L= {i,j,5,1,1,5};
					resultat.add(L);
				}
				if (coupPossible(i, j, 1, 5, 1, 5)) {
					Integer[] L= {i,j,1,5,1,5};
					resultat.add(L);
				}
			}
		}
		return resultat;
	}
	
	public Integer[] coupGagnant(){
		ArrayList<Integer[]> resultat = coupsPossibles();
		for (int i=0; i<resultat.size( );i ++){
			Integer[] L=resultat.get(i);
			addNewCell(L[0],L[1],L[2],L[3],L[4],L[5]);
			if(isOver()&&getgagnant()==5) {  // ordi = 5
				addNewCell(L[0],L[1],0,0,0,0);
				return L;
			}
			else {
				addNewCell(L[0],L[1],0,0,0,0);
			}
		}
		Integer[] L = {0,0,0,0,0,0}; // permet d'indiquer facilement qu'il n'y a pas de coup gagnant
		return L;
	}
	
	public Integer[] parerMenace(){    // peut-on parer plusieurs menaces � la fois ? avec coups obligatoires par ex
		ArrayList<Integer[]> resultat = coupsPossibles(); // + comment l'ordi r�agit ? d�fend dans cette case puis teste les alentours ?
		for (int i=0; i<resultat.size( );i ++){
			Integer[] L=resultat.get(i);
			addNewCell(L[0],L[1],L[2],L[3],L[4],L[5]);
			if(isOver()&&getgagnant()==1) {
				addNewCell(L[0],L[1],0,0,0,0);
				Integer[] M = {L[0],L[1]}; // conna�tre la case suffit pour parer la menace
				return M;
			}
			else {
				addNewCell(L[0],L[1],0,0,0,0);
			}
		}
		Integer[] M = {3,3}; // permet d'indiquer facilement qu'il n'y a pas de menace (case initiale)
		return M;
	}
	
	public void tourDeJeu2(int i, int j, int haut, int bas, int gauche, int droite) { //coup humain + ordi
		if (coupPossible(i, j, haut, bas, gauche, droite)) {
			addNewCell(i, j, haut, bas, gauche, droite);
			if (situationInterdite()) {
				addNewCell(i, j, 0, 0, 0, 0);
				System.out.println("Coup ammenant � une situation interdite, jouez un autre coup");
				return;
			}			
			boolean interdit = jouerPlusieursCoupsObligatoires();
			if (interdit) {
				addNewCell(i, j, 0, 0, 0, 0);
				System.out.println("Coup ammenant � une situation interdite, jouez un autre coup");
				return;
			}
			else {
				Integer[] L = coupGagnant();
				Integer[] M = {0,0,0,0,0,0};
				if (!L.equals(M)) {
					addNewCell(L[0], L[1], haut, bas, gauche, droite);
					return;
				}
				else {
					Integer[] N = parerMenace();
					Integer[] O = {0,0};
					if (!N.equals(0)) {  // l'ordinateur tente les 6 d�fenses possibles
						if (coupPossible(N[0],N[1],1,1,5,5)) {
							addNewCell(N[0],N[1],1,1,5,5);
							if(!isOver()) {
								return;
							}
							else {
								addNewCell(0,0,0,0,0,0);
							}
						}
						addNewCell(N[0],N[1],5,5,1,1);
						if(!isOver()) {
							return;
						}
						else {
							addNewCell(0,0,0,0,0,0);
						}
						addNewCell(N[0],N[1],1,5,5,1);
						addNewCell(N[0],N[1],5,1,5,1);
						addNewCell(N[0],N[1],5,1,1,5);
						addNewCell(N[0],N[1],1,5,1,5);
					}
				}
					
				}
				
			}
		else {
			System.out.println("Coup ill�gal, jouez un autre coup"); 
			return;
		}		
	}
	
}
