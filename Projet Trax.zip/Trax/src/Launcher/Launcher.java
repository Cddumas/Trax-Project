package Launcher;

import Metier.Engine;


public class Launcher {
	
	public static void main(String... Parameter1) {
		Engine e = new Engine();
		e.play();

}
}