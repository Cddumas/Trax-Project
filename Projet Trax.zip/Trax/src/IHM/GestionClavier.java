package IHM;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import Metier.Engine;

public class GestionClavier implements KeyListener{
	
	private GamePanel panneau;
	private Engine engine;
	private GestionSouris souris;
	
	public GestionClavier(GamePanel p,GestionSouris souris) {
		this.panneau =p;
		this.engine=this.panneau.getEngine();
		this.souris=souris;		
	}

	@Override
	public void keyPressed(KeyEvent m) {	
		if (m.getKeyCode()==97) {
			souris.setChoixTuile(true);
			souris.setHaut(1);
			souris.setBas(1);
			souris.setGauche(5);
			souris.setDroite(5);
			return;
		}
		
		if (m.getKeyCode()==98) {
			souris.setChoixTuile(true);
			souris.setHaut(5);
			souris.setBas(5);
			souris.setGauche(1);
			souris.setDroite(1);
			return;
		}
		
		if (m.getKeyCode()==99) {
			souris.setChoixTuile(true);
			souris.setHaut(1);
			souris.setBas(5);
			souris.setGauche(5);
			souris.setDroite(1);
			return;
		}
		
		if (m.getKeyCode()==100) {
			souris.setChoixTuile(true);
			souris.setHaut(5);
			souris.setBas(1);
			souris.setGauche(5);
			souris.setDroite(1);
			return;
		}
		
		if (m.getKeyCode()==101) {
			souris.setChoixTuile(true);
			souris.setHaut(5);
			souris.setBas(1);
			souris.setGauche(1);
			souris.setDroite(5);
			return;
		}
		
		if (m.getKeyCode()==102) {
			souris.setChoixTuile(true);
			souris.setHaut(1);
			souris.setBas(5);
			souris.setGauche(1);
			souris.setDroite(5);
			return;
		}
		else {
			return;
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
	}

}
