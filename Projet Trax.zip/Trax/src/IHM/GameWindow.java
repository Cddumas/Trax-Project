package IHM;

import java.awt.Dimension;

import javax.swing.JFrame;
import Metier.Engine;
import IHM.GamePanel;
import IHM.GameWindow;
import IHM.GestionSouris;

public class GameWindow extends JFrame {
	
	private Engine engine;
	private GamePanel panneau;

	public GameWindow(Engine e) {
		this.engine=e;
		this.panneau=new GamePanel (e);
		this.add(this.panneau);
	}
	
	public GamePanel getPanneau() {
		return panneau;
	}
	public void setPanneau(GamePanel panneau) {
		this.panneau = panneau;
	}
	
	public GamePanel getGamePanel() {
		return panneau;
	}

	
	public void setGamePanel(GamePanel gamePanel) {
		this.panneau = gamePanel;
	}
	
	public Engine getEngine() {
		return engine;
	}

	
	public void setEngine(Engine engine) {
		this.engine = engine;
	}



	
	public void init() {
		
		GameWindow fenetre = new GameWindow(panneau.getEngine());
		
		fenetre.setTitle("Jeu-Trax");
		Dimension dimension = new Dimension();
		dimension.setSize((engine.getL()+1)*100.0,(engine.getH()+3)*100.0);
		fenetre.setPreferredSize(dimension);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fenetre.pack();
		fenetre.setVisible(true);		
		fenetre.add(panneau);
		GestionSouris Souris = new GestionSouris(fenetre.getPanneau());
		fenetre.addMouseListener(Souris);
		fenetre.addKeyListener(new GestionClavier(fenetre.getPanneau(),Souris));
	}

	





	

	
	

	

	


}
