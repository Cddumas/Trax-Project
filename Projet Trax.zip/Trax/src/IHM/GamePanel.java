package IHM;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Metier.Cell;
import Metier.Engine;
import IHM.GameWindow;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;





public class GamePanel extends JPanel {
	
	private GameWindow gameWindow;
	private Color mycolor= Color.red;
	private boolean fin =new Boolean(false);
	private Metier.Engine engine;
	
	public void setFin(boolean fin) {
		this.fin = fin;
	}
	
	public Metier.Engine getEngine() {
		return engine;
	}
	
	public GamePanel(Metier.Engine e) {
		this.engine=e;
	}
	

	public void paintComponent(Graphics graphics) {
		if (engine.isOver()) {
			if (engine.getgagnant()==1) {
				JOptionPane.showMessageDialog(this, "fin du jeu! Blanc a gagn�");
			}
			else {
			JOptionPane.showMessageDialog(this, "fin du jeu! Rouge a gagn�");
			}
		}
		Graphics2D g2 = (Graphics2D) graphics;
		super.paintComponent(g2);
		int x = 0;
		int y = 0;
		int h = engine.getH();
		int l = engine.getL();
		Cell[][] plateau = getEngine().getPlateau();
		
		Stroke stroke = new BasicStroke(3);
		g2.setStroke(stroke);
		
		g2.setColor(Color.darkGray);
		g2.fillRect(0,   h*100+50, 100, 100);
		g2.fillRect(125, h*100+50, 100, 100);
		g2.fillRect(250, h*100+50, 100, 100);
		g2.fillRect(375, h*100+50, 100, 100);
		g2.fillRect(500, h*100+50, 100, 100);
		g2.fillRect(625, h*100+50, 100, 100);
		
		g2.setColor(Color.black);
		g2.drawRect(0,   h*100+50, 100, 100);
		g2.drawRect(125, h*100+50, 100, 100);
		g2.drawRect(250, h*100+50, 100, 100);
		g2.drawRect(375, h*100+50, 100, 100);
		g2.drawRect(500, h*100+50, 100, 100);
		g2.drawRect(625, h*100+50, 100, 100);
		
		Stroke stroke2 = new BasicStroke(3);
		g2.setStroke(stroke2);
		
		g2.setColor(Color.white);
		g2.drawLine(50,  h*100+50,  50,  h*100+150);
		g2.drawLine(125, h*100+100, 225, h*100+100);
		g2.drawLine(300, h*100+50,  350, h*100+100);
		g2.drawLine(425, h*100+150, 475, h*100+100);
		g2.drawLine(500, h*100+100, 550, h*100+150);
		g2.drawLine(625, h*100+100, 675, h*100+50);
		
		g2.setColor(Color.red);
		g2.drawLine(0,   h*100+100, 100,  h*100+100);
		g2.drawLine(175, h*100+50,  175,  h*100+150);
		g2.drawLine(250, h*100+100, 300,  h*100+150);
		g2.drawLine(375, h*100+100, 425,  h*100+50);
		g2.drawLine(550, h*100+50,  600,  h*100+100);
		g2.drawLine(675, h*100+150, 725,  h*100+100);
		
		g2.setColor(Color.black);
		g2.setFont(g2.getFont().deriveFont(Font.BOLD, 32.0f));
		g2.drawString("1", 40,  h*100+180);
		g2.drawString("2", 165, h*100+180);
		g2.drawString("3", 290, h*100+180);
		g2.drawString("4", 415, h*100+180);
		g2.drawString("5", 540, h*100+180);
		g2.drawString("6", 665, h*100+180);

		
		for (int i = 0; i < engine.getH(); i++) {
			for (int j = 0; j < engine.getL(); j++) {
				
				int haut = plateau[i][j].getHaut();
				int bas =plateau[i][j].getBas();
				int gauche = plateau[i][j].getGauche();
				int droite = plateau[i][j].getDroite();
				int nbrDeTrait=0;
				x = 100 * j;
				y = 100 * i;
				
				Stroke stroke3 = new BasicStroke(3);
				g2.setStroke(stroke3);
				
				g2.setColor(Color.white);
				g2.fillRect(x, y,100, 100);
				g2.setColor(Color.black);
				g2.drawRect(x, y,100, 100);
				
				if (haut==bas && haut==1) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.white);
					g2.drawLine(x+50,y,x+50,y+100);
					nbrDeTrait+=1;
				}
				if (haut==bas && haut==5) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.red);
					g2.drawLine(x+50,y,x+50,y+100);
					nbrDeTrait+=1;
				}
				
				if (haut==gauche && haut==1) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.white);
					g2.drawLine(x+50,y,x,y+50);
					nbrDeTrait+=1;
				}
				if (haut==gauche && haut==5) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.red);
					g2.drawLine(x+50,y,x,y+50);
					nbrDeTrait+=1;
				}
				
				if (haut==droite && haut==1) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.white);
					g2.drawLine(x+50,y,x+100,y+50);	
					nbrDeTrait+=1;
				}
				if (haut==droite && haut==5) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.red);
					g2.drawLine(x+50,y,x+100,y+50);
					nbrDeTrait+=1;
				}
				
				if (droite==gauche && droite==1) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.white);
					g2.drawLine(x,y+50,x+100,y+50);
					nbrDeTrait+=1;
				}
				if (droite==gauche && droite==5) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.red);
					g2.drawLine(x,y+50,x+100,y+50);
					nbrDeTrait+=1;
				}
				
				if (droite==bas && droite==1) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.white);
					g2.drawLine(x+50,y+100,x+100,y+50);
					nbrDeTrait+=1;
				}
				if (droite==bas && droite==5) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.red);
					g2.drawLine(x+50,y+100,x+100,y+50);
					nbrDeTrait+=1;
				}
				
				if (bas==gauche && bas==1) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.white);
					g2.drawLine(x,y+50,x+50,y+100);
					nbrDeTrait+=1;
				}
				if (bas==gauche && bas==5) {
					if (nbrDeTrait==0){
					g2.setColor(Color.darkGray);
					g2.fillRect(x, y,100, 100);
					}
					g2.setColor(Color.red);
					g2.drawLine(x,y+50,x+50,y+100);
					nbrDeTrait+=1;
				}
			}
		}
	}
}
