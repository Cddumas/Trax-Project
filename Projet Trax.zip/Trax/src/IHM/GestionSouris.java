package IHM;


import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


import Metier.Engine;

public class GestionSouris implements MouseListener{
	
	private boolean choixTuile=false;
	private int haut=0;
	private int bas=0;
	private int gauche=0;
	private int droite=0;
	private GamePanel panneau;
	private Engine engine;
	
	public int getHaut() {
		return haut;
	}

	public void setHaut(int haut) {
		this.haut = haut;
	}

	public int getBas() {
		return bas;
	}

	public void setBas(int bas) {
		this.bas = bas;
	}

	public int getGauche() {
		return gauche;
	}

	public void setGauche(int gauche) {
		this.gauche = gauche;
	}

	public int getDroite() {
		return droite;
	}

	public void setDroite(int droite) {
		this.droite = droite;
	}

	
	public GestionSouris(GamePanel p) {
		this.panneau =p;
		this.engine=this.panneau.getEngine();		
	}
	
	public boolean getChoixTuile() {
		return choixTuile;
	}


	public void setChoixTuile(boolean choixTuile) {
		this.choixTuile = choixTuile;
	}

	
	public void mouseClicked(MouseEvent m) {
		// TODO Auto-generated method stub
	
	}
		
	

	@Override
	public void mouseEntered(MouseEvent m) {
		// TODO Auto-generated method stub
		
	}
		

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent m) {

		int h = engine.getH();
		int l = engine.getL();		
		int x= m.getX();
		x=x-10; // d�calage dans l'affichage
		int y= m.getY();
		y=y-35; //decalage dans l'affichage
		
		
		if (0<x && x<100 && h*100+50<y && y<h*100+150) {
			choixTuile=true;
			haut=1;
			bas=1;
			gauche=5;
			droite=5;
			return;
		}
		else if (125<x && x<225 && h*100+50<y && y<h*100+150) {
			choixTuile=true;
			haut=5;
			bas=5;
			gauche=1;
			droite=1;
			return;
	}
		else if (250<x && x<350 && h*100+50<y && y<h*100+150) {
			choixTuile=true;
			haut=1;
			bas=5;
			gauche=5;
			droite=1;
			return;
	}
		else if (375<x && x<475 && h*100+50<y && y<h*100+150) {
			choixTuile=true;
			haut=5;
			bas=1;
			gauche=5;
			droite=1;
			return;
	}
		
		else if (500<x && x<600 && h*100+50<y && y<h*100+150) {
			choixTuile=true;
			haut=5;
			bas=1;
			gauche=1;
			droite=5;
			return;
	}
		else if (625<x && x<725 && h*100+50<y && y<h*100+150) {
			choixTuile=true;
			haut=1;
			bas=5;
			gauche=1;
			droite=5;
			return;
	}
		
		else if (x>h*100 ||  y>l*100) {
			return;
		}
		
		else {
			x= x/100;
			y=y/100;
			if (choixTuile) {
				engine.tourDeJeu(y,x,haut,bas,gauche,droite);
				choixTuile=false;
				panneau.repaint();			
			}
		}
		
	}

	@Override
	public void mouseReleased(MouseEvent m) {
	}

}